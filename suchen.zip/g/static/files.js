const längeBtn = document.getElementById('länge-ändern-btn');
const formFirstPart = document.getElementById('first-part');


$("#länge-ändern-btn").on( "click", function() {
    $('#first-part').toggle();
})